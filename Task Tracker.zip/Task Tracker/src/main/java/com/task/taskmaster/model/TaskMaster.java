package com.task.taskmaster.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "taskmaster")
public class TaskMaster {
    @Id
    @Column(name = "id")
    private int id;
    @Column(name = "project_id")
    private int projectId;
    @Column(name = "task_subject")
    private String taskSubject;
    @Column(name = "desc")
    private String description;
    @Column(name = "task_doc")
    private LocalDate taskDoc;
    @Column(name = "task_dof")
    private LocalDate taskDof;
    @Column(name = "task_createdby")
    private String taskCreatedBy;
    @Column(name = "task_assignedto")
    private String taskAssignedTo;

    public TaskMaster() {
    }

    public TaskMaster(int id, int projectId, String taskSubject, String description,
                      LocalDate taskDoc, LocalDate taskDof, String taskCreatedBy, String taskAssignedTo) {
        this.id = id;
        this.projectId = projectId;
        this.taskSubject = taskSubject;
        this.description = description;
        this.taskDoc = taskDoc;
        this.taskDof = taskDof;
        this.taskCreatedBy = taskCreatedBy;
        this.taskAssignedTo = taskAssignedTo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public String getTaskSubject() {
        return taskSubject;
    }

    public void setTaskSubject(String taskSubject) {
        this.taskSubject = taskSubject;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getTaskDoc() {
        return taskDoc;
    }

    public void setTaskDoc(LocalDate taskDoc) {
        this.taskDoc = taskDoc;
    }

    public LocalDate getTaskDof() {
        return taskDof;
    }

    public void setTaskDof(LocalDate taskDof) {
        this.taskDof = taskDof;
    }

    public String getTaskCreatedBy() {
        return taskCreatedBy;
    }

    public void setTaskCreatedBy(String taskCreatedBy) {
        this.taskCreatedBy = taskCreatedBy;
    }

    public String getTaskAssignedTo() {
        return taskAssignedTo;
    }

    public void setTaskAssignedTo(String taskAssignedTo) {
        this.taskAssignedTo = taskAssignedTo;
    }

    @Override
    public String toString() {
        return "TaskMaster{" +
                "id=" + id +
                ", projectId=" + projectId +
                ", taskSubject='" + taskSubject + '\'' +
                ", description='" + description + '\'' +
                ", taskDoc=" + taskDoc +
                ", taskDof=" + taskDof +
                ", taskCreatedBy='" + taskCreatedBy + '\'' +
                ", taskAssignedTo='" + taskAssignedTo + '\'' +
                '}';
    }
}
