package com.task.taskmaster.controller;

import com.task.taskmaster.model.TaskMaster;
import com.task.taskmaster.repo.TaskMasterRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/taskmaster")
public class TaskMasterController {

    @Autowired
    private TaskMasterRepo taskMasterRepo;

    @GetMapping("/all")
    private List<TaskMaster> getAllTasks(){
        return taskMasterRepo.findAll();
    }
}
