package com.task.taskmaster.repo;

import com.task.taskmaster.model.TaskMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TaskMasterRepo extends JpaRepository<TaskMaster,Integer> {
}
